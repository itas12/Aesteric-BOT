// metais.js
module.exports = {
  nome: "TED BOT"  // Coloque o nome aqui
}