30 path=rias-api/funções.js
